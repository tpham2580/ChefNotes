package main

import (
	"fmt"
)

func lineOne() {
	fmt.Println("lineOne function")
}

func lineTwo() {
	fmt.Println("lineTwo function")
}

func lineThree() {
	fmt.Println("lineThree function")
}

func main() {
	lineOne()
	lineTwo()
	lineThree()
}
